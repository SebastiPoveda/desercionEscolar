package com.example.desercion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DesercionApplicationTests {

	@Test
	void contextLoads() {
	}

}
