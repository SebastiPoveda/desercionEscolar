$(document).ready(function(){
    getInfoUser();
    getQuestionsUser();
    getUser();
});

function getInfoUser(){
    $.ajax({
        headers:{
        	"Authorization": "Bearer "+ Cookies.get('token')
        },
        success : function(p) {
            $("#infoUser").empty();
            let t = Cookies.get("token");
            let user = parseJwt(t);

                let k=`<style>
                h3{
                 color: black;
                p{
                 color: black;
                }
                }
                </style><div class="col">
                            <div class="card">
                                <div class="card-body">
                                    <h3 class="card-title">${user["USA"]}</h3>
                                    <p class="card-text">${user["EMAIL"]}</p>
                                </div>
                            </div>
                        </div>`;
            $("#infoUser").append(k);
        },
        error : function(xhr, status) {
            alert('ha sucedido un problema');
        },
        complete : function(xhr, status) {
            //  alert('Petición realizada');
        }
    });
   }
function getQuestionsUser(){
    $.ajax({
        url : "/api/v1/forum/user",
        type : 'GET',
        dataType : 'json',
        headers:{
        	"Authorization": "Bearer "+ Cookies.get('token')
        },
        success : function(p) {
            $("#preguntasUsuario").empty();
            for(i=0;i<p.length;i++){
                let k=`<style>h3{
                                   color: black;
                                }
                                p{
                                   color: black;
                                }
                </style><div class="col">
                            <div class="card">
                                <div class="card-body">
                                    <h3 class="card-title">${p[i].titulo}</h3>
                                    <p class="card-text">${p[i].contenido}</p>
                                </div>
                            </div>
                        </div>`;
                $("#preguntasUsuario").append(k);
            }
        },
        error : function(xhr, status) {
            console.log('ha sucedido un problema');
        },
        complete : function(xhr, status) {
            //  alert('Petición realizada');
        }
    });
   }
function getUser(){
    $.ajax({
        url : "/api/v1/user/getUser",
        type : 'GET',
        dataType : 'json',
        headers:{
        	"Authorization": "Bearer "+ Cookies.get('token')
        },
        success : function(p) {
            paintFavs(p);
        },
        error : function(xhr, status) {
            console.log('ha sucedido un problema');
        },
        complete : function(xhr, status) {
            //  alert('Petición realizada');
        }
    });
   }
   function parseJwt(token) {
       const base64Url = token.split('.')[1];
       const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
       const jsonPayload = decodeURIComponent(
           atob(base64)
               .split('')
               .map(function (c) {
                   return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
               })
               .join('')
       );
       return JSON.parse(jsonPayload);
   }
function paintFavs(user) {
    $("#favoritos").empty();
    for (let i = 0; i < user.listaFavoritosA.length; i++) {
        let k = `<hr>
                 <h6 class="card-subtitle mb-2 text-body-secondary">${user.listaFavoritosA[i].name}</h6>`;
        $("#favoritos").append(k);
    }for (let i = 0; i < user.listaFavoritosC.length; i++) {
        let j = `<hr>
                <h6 class="card-subtitle mb-2 text-body-secondary">${user.listaFavoritosC[i].nombre}</h6>`;
                $("#favoritos").append(j);
    }
}
