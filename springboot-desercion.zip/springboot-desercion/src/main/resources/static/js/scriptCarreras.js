$('document').ready(function(){
    carreraRequest();
});
function carreraRequest() {
    $.ajax({
        url: "/api/v1/careers/all",
        type: "GET",
        contentType: "application/json",
        dataType: "json",
        headers:{
            "Authorization": "Bearer "+ Cookies.get('token')
        },
        success: function (rta) {
            paintCarrera(rta);
        },
        error: function (xhr, status) {
            alert('F');
        },
        complete: function (xhr, status) {
            //alert('Petición realizada');
        }

    });
}

function paintCarrera(c) {
    let k = "";
    for (let i = 0; i < c.length; i++) {
        k += `
            <div class="col">
              <div class="card border-success">
                <div class="card-body">
                  <h6 class="card-title" style="font-size: 25px;"><strong>${c[i].nombre}</strong></h6>
                  <h6>Creditos: ${c[i].creditos}</h6>
                  <h6>Semestres: ${c[i].semestres}</h6>
                  <h6><small class="text-body-secondary">Modalidad: ${c[i].modalidad}</small></h6>
                </div>
                <div class="card-footer">
                  <div class="form-check">
                    <input class="form-check-input" type="checkbox" value="${c[i].carrerasID}">
                    <label class="form-check-label">
                      Seguir
                    </label>
                  </div>

                </div>
              </div>
            </div>
        `
    }
    $("#carrerasInicio").empty();
    $("#carrerasInicio").append(k);
}
 function Checking() {
	 // seleccionar todas las casillas de verificación en la página
	 const checkboxes = document.querySelectorAll('input[type="checkbox"]');

	 let carreras = [];

	 // iterar sobre las casillas de verificación y encontrar las que están marcadas
	 for (let i = 0; i < checkboxes.length; i++) {
		 if (checkboxes[i].checked) {
			 carreras.push(checkboxes[i].value);
		 }
	 }
	  $.ajax({

     		url:"/api/v1/user/favsC",
     		type:"POST",
     		contentType:"application/json",
     		dataType:"json",
     		headers:{
     		  "Authorization": "Bearer "+ Cookies.get('token')
     		},


     		data:JSON.stringify(carreras),

     		success: function(rta) {
     			window.location.replace("profile.html");
     		},
     		error: function(xhr, status) {
     			alert('Disculpe, existió un problema');
     		},
     		complete: function(xhr, status) {
     			//alert('Petición realizada');
     		}

     	});
 }