 function loginData(){

	let email = $("#username").val();
	let password = $("#password").val();

	 let data = {
		 email:email,
		 password: password
	 }
	 
	 $.ajax({
		 
		 url:"/api/v1/auth/authenticate",
		 type:"POST",
		 contentType:"application/json",
		 dataType:"json",

		 data:JSON.stringify(data),

		 success: function(rta) {
			 $("#username").val("");
			 $("#password").val("");
			 Cookies.set('token',rta['token']);
			 window.location.replace("profile.html");
		 },
		 error: function(xhr, status) {
			 alert('Usuario no existente');
		 },
		 complete: function(xhr, status) {
			 //alert('Petición realizada');
		 }

	 });
 }

 function logOut(){
	Cookies.remove('token');
	window.location.replace("index.html");
 }

 function registerData(){

	 let firstname = $("#firstname").val();
	 let lastname = $("#lastname").val();
	 let email = $("#email").val();
	 let password = $("#password").val();

	 let data = {
		 firstname: firstname,
		 lastname: lastname,
		 email: email,
		 password: password
	 }

	 $.ajax({

		 url:"/api/v1/auth/register",
		 type:"POST",
		 contentType:"application/json",
		 dataType:"json",

		 data:JSON.stringify(data),

		 success: function(rta) {
			 Cookies.set("token",rta['token']);
			 window.location.replace("pagina_inicio_1.html");
		 },
		 error: function(xhr, status) {
			 alert('Disculpe, existió un problema');
		 },
		 complete: function(xhr, status) {
			 //alert('Petición realizada');
		 }

	 });
 }

 function parseJwt(token) {
     const base64Url = token.split('.')[1];
     const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
     const jsonPayload = decodeURIComponent(
         atob(base64)
             .split('')
             .map(function (c) {
                 return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
             })
             .join('')
     );
     return JSON.parse(jsonPayload);
 }