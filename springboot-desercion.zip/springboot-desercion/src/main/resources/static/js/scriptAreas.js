$('document').ready(function(){
    areaRequest();
});
function areaRequest() {
    $.ajax({
        url: "/api/v1/area/all",
        type: "GET",
        contentType: "application/json",
        dataType: "json",
        headers:{
           "Authorization": "Bearer "+ Cookies.get('token')
        },
        success: function (rta) {
            paintArea(rta);
        },
        error: function (xhr, status) {
            alert('F');
        },
        complete: function (xhr, status) {
            //alert('Petición realizada');
        }

    });
}

function paintArea(a) {
    let k = "";
    for (let i = 0; i < a.length; i++) {
        k += `
            <div class="col">
                <div class="card h-100 border-success">
                    <div class="card-body">
                        <h5 class="card-title" style="font-size: 25px;">${a[i].name} </h5>
                    </div>
                    <div class="card-footer">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" value="${a[i].areaId}">
                            <label class="form-check-label">
                            Seguir
                            </label>
                        </div>
                    </div>
               </div>
            </div>
        `
    }

    $("#areasInicio").empty();
    $("#areasInicio").append(k);
}
 function Checking() {
	 // seleccionar todas las casillas de verificación en la página
	 const checkboxes = document.querySelectorAll('input[type="checkbox"]');

	 let areas = [];

	 // iterar sobre las casillas de verificación y encontrar las que están marcadas
	 for (let i = 0; i < checkboxes.length; i++) {
		 if (checkboxes[i].checked) {
			 areas.push(checkboxes[i].value);
		 }
	 }
	  $.ajax({

     		url:"/api/v1/user/favsA",
     		type:"POST",
     		contentType:"application/json",
     		dataType:"json",
     		headers:{
     		  "Authorization": "Bearer "+ Cookies.get('token')
     		},


     		data:JSON.stringify(areas),

     		success: function(rta) {
     			window.location.replace("pagina_inicio_2.html");
     		},
     		error: function(xhr, status) {
     			alert('Disculpe, existió un problema');
     		},
     		complete: function(xhr, status) {
     			//alert('Petición realizada');
     		}

     	});
 }