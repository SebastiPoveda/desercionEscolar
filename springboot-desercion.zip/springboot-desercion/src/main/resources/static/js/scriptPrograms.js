$(document).ready(function(){
    getUser();
});
function paintSugerencia1(c) {
    let k = "";
    for (let i = 0; i < c.length; i++) {
        k += `
        <div class="col-lg-4">
            <div class="card">
                <img src="${c[i]}" class="card-img-top" alt="${c[i].name}">
                <div class="card-body">
                    <h5 class="card-title">${c[i].listaFavoritosC[i].nombre}</h5>
                    <p class="card-text">${c[i]}</p>
                </div>
            </div>
        </div>
        `
    }
    $("#row1").empty();
    $("#row1").append(k);
}

function paintRCarrera1(c) {
    let k = "";
    for (let i = 0; i < c.length; i++) {
        k += `
        <div class="col-lg-6 col-md-12 col-sm-12 d-flex justify-content-start my-5 icono-wrap">
            <img src="${c[i]}" alt="${c[i]}" width="180" height="160">
            <div>
                <h3 class="fs-5 mt-4 px-4 pb-1">${c[i]}</h3>
                <p class="px-4">Desarrollo de aplicaciones WEB, moviles y ecommerce</p>
            </div>
        </div>
        `
    }
    $("#servicios-fila-1").empty();
    $("#servicios-fila-1").append(k);
}

function paintRCarrera2(c) {
    let k = "";
    for (let i = 0; i < c.length; i++) {
        k += `
        <div class="col-lg-4 col-md-12 col-sm-12 d-flex justify-content-start my-5 icono-wrap">
            <img src="${c[i]}" alt="${c[i]}" width="180" height="160">
            <div>
                <h3 class="fs-5 mt-4 px-4 pb-1">${c[i]}</h3>
                <p class="px-4">Desarrollo de aplicaciones WEB, moviles y ecommerce</p>
            </div>
        </div>
        `
    }
    $("#servicios-fila-2").empty();
    $("#servicios-fila-2").append(k);
}

function paintRCarrera3(c) {
    let k = "";
    for (let i = 0; i < c.length; i++) {
        k += `
        <div class="col-lg-6 col-md-12 col-sm-12 d-flex justify-content-start my-5 icono-wrap">
            <img src="${c[i]}" alt="${c[i]}" width="180" height="160">
            <div>
                <h3 class="fs-5 mt-4 px-4 pb-1">${c[i]}</h3>
                <p class="px-4">Desarrollo de aplicaciones WEB, moviles y ecommerce</p>
            </div>
        </div>
        `
    }
    $("#servicios-fila-3").empty();
    $("#servicios-fila-3").append(k);
}
function paintFavs(user) {
    $("#row1").empty();
    for (let i = 0; i < user.listaFavoritosA.length; i++) {
        let k = `<div class="col-lg-4">
                      <div class="card border-success mb-3 h-100 text-bg-success">
                             <div class="card-body">
                            <h3 class="card-title">${user.listaFavoritosA[i].name}</h3>
                            <p class="card-text">AREAS</p>
                         </div>
                     </div>
                 </div>
                 `;
        $("#row1").append(k);
    }
    $("#row2").empty();
    for (let i = 0; i < user.listaFavoritosC.length; i++) {
        let j = `<div class="col-lg-4">
                                       <div class="card border-success mb-3 h-100 text-bg-success">
                                              <div class="card-body">
                                             <h4 class="card-title">${user.listaFavoritosC[i].nombre}</h4>
                                             <p class="card-text">Modalidad: ${user.listaFavoritosC[i].modalidad}</p>
                                             <p class="card-text">Creditos: ${user.listaFavoritosC[i].creditos}</p>
                                          </div>
                                      </div>
                                  </div>
                `;
                $("#row2").append(j);
    }
}
function getUser(){
    $.ajax({
        url : "/api/v1/user/getUser",
        type : 'GET',
        dataType : 'json',
        headers:{
        	"Authorization": "Bearer "+ Cookies.get('token')
        },
        success : function(p) {
            console.log(p);
            paintFavs(p);
        },
        error : function(xhr, status) {
            console.log('ha sucedido un problema');
        },
        complete : function(xhr, status) {
            //  alert('Petición realizada');
        }
    });
   }