$(document).ready(function(){
    getAllPreguntas();
    getUsuarioPregunta();
});

function getAllPreguntas(){
    $.ajax({
        url : "/api/v1/forum/all",
        type : 'GET',
        dataType : 'json',
        headers:{
        	"Authorization": "Bearer "+ Cookies.get('token')
        },
        success : function(p) {
            console.log(p);
            $("#preguntas").empty();
            for(i=0;i<p.length;i++){
                let k=`<style>h3{
                                   color: black;
                                }
                                p{
                                   color: black;
                                }
                </style><div class="col">
                            <div class="card">
                                <div class="card-body">
                                    <h3 class="card-title">${p[i].titulo}</h3>
                                    <p class="card-text">${p[i].contenido}</p>
                                </div>
                            </div>
                        </div>`;
                $("#preguntas").append(k);
            }
        },
        error : function(xhr, status) {
            alert('ha sucedido un problema');
        },
        complete : function(xhr, status) {
            //  alert('Petición realizada');
        }
    });
   }
    function getUsuarioPregunta(){
        $.ajax({
            url : "/api/v1/forum/all",
            type : 'GET',
            dataType : 'json',
            headers:{
            	"Authorization": "Bearer "+ Cookies.get('token')
            },
            success : function(p) {
                console.log(p);
                $("#usuarios").empty();
                for(i=0;i<p.length;i++){
                    let fullname = p[i].usuario.firstname + ' ' + p[i].usuario.lastname;
                    let k=`<style>h3{
                                       color: black;
                                    }
                                    p{
                                       color: black;
                                    }
                    </style><div class="col">
                                <div class="card">
                                    <div class="card-body">
                                        <img src = "/api/v1/dirs/get/${p[i].usuario.foto}">
                                        <h3 class="card-title">${fullname}</h3>
                                        <p class="card-text">${p[i].usuario.email}</p>
                                    </div>
                                </div>
                            </div>`;
                    $("#usuarios").append(k);
                }
            },
            error : function(xhr, status) {
                alert('ha sucedido un problema');
            },
            complete : function(xhr, status) {
                //  alert('Petición realizada');
            }
        });
}