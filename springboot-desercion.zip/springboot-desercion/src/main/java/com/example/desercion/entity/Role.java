package com.example.desercion.entity;

public enum Role {

    USER,
    ADMIN
}
