package com.example.desercion.controller;

import com.example.desercion.auth.AuthenticationRequest;
import com.example.desercion.auth.AuthenticationResponse;
import com.example.desercion.entity.Usuario;
import com.example.desercion.repository.UsuarioCrudRepository;
import com.example.desercion.service.AuthenticationService;
import com.example.desercion.auth.RegisterRequest;
import com.example.desercion.service.UsuarioService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/auth")
@RequiredArgsConstructor
public class AuthenticationController {
    private final AuthenticationService service;
    private final UsuarioService usuarioService;
    private final UsuarioCrudRepository repository;

    @PostMapping("/register")
    public ResponseEntity<AuthenticationResponse> register(
            @RequestBody RegisterRequest request
    ) {
        if(!request.getFirstname().isBlank() && !request.getLastname().isBlank() && !request.getEmail().isBlank() && !request.getPassword().isBlank() && !repository.findByEmail(request.getEmail()).isPresent()){
                return ResponseEntity.ok(service.register(request));
        }else {
            return ResponseEntity.status(HttpStatusCode.valueOf(403)).build();
        }
    }

    @PostMapping("/authenticate")
    public ResponseEntity<AuthenticationResponse> authentication(
            @RequestBody AuthenticationRequest request
    ) {
        return ResponseEntity.ok(service.authenticate(request));
    }

    @GetMapping("/all")
    public List<Usuario> all() {
        return usuarioService.getAll();
    }


}
