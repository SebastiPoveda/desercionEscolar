package com.example.desercion.service;

import com.example.desercion.entity.Usuario;
import com.example.desercion.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Optional;

@Service
public class DirsService {
    @Value("${upload.dir}")
    private String uploadDir;
    @Autowired
    private UsuarioRepository usuarioRepository;
    public Boolean subirArchivo(MultipartFile file, int id){
        try {
            Optional<Usuario> usuario = usuarioRepository.findById(id);
            if(usuario.isPresent()){
                String nombre =System.currentTimeMillis() + file.getOriginalFilename();
                usuario.get().setFoto(nombre);
                usuarioRepository.save(usuario.get());
                Path path = Paths.get(uploadDir + "\\" + nombre);
                Files.write(path, file.getBytes());
                return true;
            }
            return false;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }
}
