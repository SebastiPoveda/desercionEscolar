package com.example.desercion.entity;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Data
@Entity
@Table(name = "carreras")
public class Carreras implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer carrerasID;
    private Integer creditos;
    private String modalidad;
    private String nombre;
    private Integer semestres;


    @ManyToMany(cascade = CascadeType.ALL)
    private List<Area> area;

    @ManyToMany(mappedBy = "listaFavoritosC")
    @JsonIgnoreProperties("listaFavoritosC")
    private List<Usuario> usuarios;

    @ManyToMany(cascade = CascadeType.ALL)
    private List<Universidad> universidades;
}