package com.example.desercion;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DesercionApplication {

	public static void main(String[] args) {
		SpringApplication.run(DesercionApplication.class, args);
	}

}
