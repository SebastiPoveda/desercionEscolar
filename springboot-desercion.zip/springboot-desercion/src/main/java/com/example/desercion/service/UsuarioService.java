package com.example.desercion.service;

import com.example.desercion.entity.Area;
import com.example.desercion.entity.Carreras;
import com.example.desercion.entity.Pregunta;
import com.example.desercion.entity.Usuario;
import com.example.desercion.repository.AreaRepository;
import com.example.desercion.repository.CarrerasRepository;
import com.example.desercion.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UsuarioService {
    @Autowired
    private UsuarioRepository usuarioRepository;
    @Autowired
    private AreaRepository areaRepository;
    @Autowired
    private CarrerasRepository carreraRepository;

    public List<Usuario> getAll(){
        return usuarioRepository.getAll();
    }
    public Optional<Usuario> findById (int i){ return  usuarioRepository.findById(i);}

    public Optional<Usuario> saveFavsA(int id, int x){
        if(areaRepository.findById(id).isPresent()){
            Optional<Usuario> u = usuarioRepository.findById(x);
            Optional<Area> area = areaRepository.findById(id);
            area.get().getUsuarios().add(u.get());
            u.get().getListaFavoritosA().add(area.get());
            usuarioRepository.save(u.get());
        }
        return usuarioRepository.findById(x);
    }
    public Optional<Usuario> saveFavsC(int id, int x){
        if(carreraRepository.findById(id).isPresent()){
            Optional<Usuario> u = usuarioRepository.findById(x);
            Optional<Carreras> carreras = carreraRepository.findById(id);
            u.get().getListaFavoritosC().add(carreras.get());
            carreras.get().getUsuarios().add(u.get());
            usuarioRepository.save(u.get());
        }
        return usuarioRepository.findById(x);
    }
}
