package com.example.desercion.repository;

import com.example.desercion.entity.Area;
import com.example.desercion.entity.Carreras;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public class CarrerasRepository {

    @Autowired
    CarrerasCrudRepository carrerasCrudRepository;
    public List<Carreras> findAll(){
        return (List<Carreras>) carrerasCrudRepository.findAll();
    }
    public Carreras save(Carreras c){
        return carrerasCrudRepository.save(c);
    }
    public Optional<Carreras> findById(int id) { return carrerasCrudRepository.findById(id);}

}
