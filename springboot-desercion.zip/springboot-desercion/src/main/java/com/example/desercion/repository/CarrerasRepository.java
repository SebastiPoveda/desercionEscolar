package com.example.desercion.repository;

public class CarrerasRepository {
}
