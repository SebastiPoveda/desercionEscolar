package com.example.desercion.controller;

import com.example.desercion.service.DirsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;

@RestController
@RequestMapping("/api/v1/dirs")
public class ControllerDirs {
    @Value("${upload.dir}")
    private String uploadDir;
    @Autowired
    private DirsService dirsService;
    @PostMapping("/upload")
    public ResponseEntity<String> handleFileUpload(@RequestParam("file") MultipartFile file) {
        A a = new A();
        if(dirsService.subirArchivo(file,a.getId())){
            return ResponseEntity.status(HttpStatus.OK).body("Subido");
        }else{
            return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body("Error");
        }
    }
    @GetMapping("/get/{filename:.+}")
    public ResponseEntity<Resource> getFile(@PathVariable String filename){
        try{
            File f = new File(uploadDir + "\\" + filename);
            InputStream inputStream = new FileInputStream(f);
            InputStreamResource resource = new InputStreamResource(inputStream);
            HttpHeaders headers = new HttpHeaders();
            headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + filename + "\"");
            headers.add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_OCTET_STREAM_VALUE);
            headers.add(HttpHeaders.CONTENT_LENGTH, String.valueOf(f.length()));

            return new ResponseEntity<>(resource, headers, HttpStatus.OK);

        }catch (Exception e){
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }

    }
}
