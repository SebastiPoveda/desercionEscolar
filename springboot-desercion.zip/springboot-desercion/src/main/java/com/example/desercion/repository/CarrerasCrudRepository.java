package com.example.desercion.repository;

public interface CarrerasCrudRepository {
}
