package com.example.desercion.repository;

import com.example.desercion.entity.Carreras;
import org.springframework.data.repository.CrudRepository;

import java.util.Optional;

public interface CarrerasCrudRepository extends CrudRepository <Carreras, Integer> {
    @Override
    Optional<Carreras> findById(Integer integer);
}
