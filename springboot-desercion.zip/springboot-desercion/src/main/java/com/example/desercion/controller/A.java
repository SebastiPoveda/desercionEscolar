package com.example.desercion.controller;

import com.example.desercion.entity.Pregunta;
import com.example.desercion.entity.Usuario;
import lombok.Data;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
@Data
public class A {
    private String correo;
    private int id;

    public A(){
        if(SecurityContextHolder.getContext().getAuthentication() != null){
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            Usuario userDetails = (Usuario) authentication.getPrincipal();
            correo = userDetails.getUsername();
            id = userDetails.getId();
        }
    }
}
