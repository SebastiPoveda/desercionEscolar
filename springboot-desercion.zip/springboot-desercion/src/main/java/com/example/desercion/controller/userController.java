package com.example.desercion.controller;


import com.example.desercion.service.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/api/v1/user")
public class userController {
    @Autowired
    UsuarioService usuarioService;
}

