package com.example.desercion.controller;


import com.example.desercion.entity.Pregunta;
import com.example.desercion.entity.Usuario;
import com.example.desercion.service.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;


@RestController
@RequestMapping("/api/v1/user")
public class userController {
    @Autowired
    UsuarioService usuarioService;
    @GetMapping("/getUser")
    public Optional<Usuario> getUser() {
        A a = new A();
        return usuarioService.findById(a.getId());
    }
    @PostMapping("/favsA")
    public Optional<Usuario> saveFavsA(@RequestBody List<Integer> ids){
        A a = new A();
        for (int id : ids) {
            usuarioService.saveFavsA(id, a.getId());
        }
        return usuarioService.findById(a.getId());
    }
    @PostMapping("/favsC")
    public Optional<Usuario> saveFavsC(@RequestBody List<Integer> ids) {
        A a = new A();
        // Procesar la lista de IDs de carreras
        for (int id : ids) {
            usuarioService.saveFavsC(id, a.getId());
        }
        return usuarioService.findById(a.getId());
    }

}

