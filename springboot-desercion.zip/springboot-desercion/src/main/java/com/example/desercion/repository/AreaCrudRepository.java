package com.example.desercion.repository;

import com.example.desercion.entity.Area;
import com.example.desercion.entity.Pregunta;
import com.example.desercion.entity.Usuario;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.core.CrudMethods;

import java.util.Optional;

public interface AreaCrudRepository extends CrudRepository<Area,Integer> {
    public Optional<Area> findById (int id);
}
